#ifndef NETWORKREQUSETTYPE_H
#define NETWORKREQUSETTYPE_H

#include<QObject>

class NetworkRequestType : public QObject
{
    Q_OBJECT
    Q_ENUMS(RequestType)
public:

    enum RequestType
    {
        E_login=1,//登录接口
        E_logout=2//退出接口
    };
};
#endif // NETWORKREQUSETTYPE_H
