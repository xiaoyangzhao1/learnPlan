#ifndef NETWORKREQUEST_H
#define NETWORKREQUEST_H

#include <QObject>
#include<QNetworkRequest>
#include"networkrequsettype.h"
class NetworkRequest
{
public:
    NetworkRequest();
    ~NetworkRequest();

    QNetworkRequest* getRequest();

    //对应的网络请求类型
    NetworkRequestType::RequestType requestType();

    //设置网络请求类型
    void setRequestType(NetworkRequestType::RequestType);

private:
    NetworkRequestType::RequestType m_requestType;
    QNetworkRequest *m_request;
};

#endif // NETWORKREQUEST_H
