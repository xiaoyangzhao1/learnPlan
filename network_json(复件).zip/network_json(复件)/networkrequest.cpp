#include "networkrequest.h"

NetworkRequest::NetworkRequest()
{

}

NetworkRequest::~NetworkRequest()
{

}

QNetworkRequest *NetworkRequest::getRequest()
{
    return m_request;
}

NetworkRequestType::RequestType NetworkRequest::requestType()
{
    return m_requestType;
}

void NetworkRequest::setRequestType(NetworkRequestType::RequestType type)
{
    m_requestType=type;
}
