#include "networkreply.h"

NetworkReply::NetworkReply(QObject *parent) : QObject(parent)
{

}

NetworkReply::~NetworkReply()
{
    qDebug()<<"释放reply数据";
#ifndef Q_OS_WIN
    m_reply->deleteLater();
#endif
}

void NetworkReply::setReply(QNetworkReply *reply)
{
    m_reply=reply;
}

QNetworkReply *NetworkReply::getReply()
{
    return m_reply;
}

NetworkRequestType::RequestType NetworkReply::reply_getRequestType()
{
    return m_reply_requestType;
}

void NetworkReply::reply_setRequestType(NetworkRequestType::RequestType type)
{
    m_reply_requestType=type;
}

void NetworkReply::slot_myReplayFinished()
{
    emit sig_myReplyFinished();
}
