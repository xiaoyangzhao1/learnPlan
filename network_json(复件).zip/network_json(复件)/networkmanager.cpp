#include "networkmanager.h"

NetworkManager::NetworkManager(QObject *parent) : QObject(parent)
{

}

NetworkManager::~NetworkManager()
{
    delete m_helper;
}

bool NetworkManager::get(NetworkRequest *request)
{
    m_helper->get(request);
    return true;
}
