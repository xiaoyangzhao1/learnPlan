#ifndef NETWORKMANAGER_H
#define NETWORKMANAGER_H
#include"networkrequest.h"

#include <QObject>
#include<QIODevice>

class NetworkManager : public QObject
{
    Q_OBJECT
public:
    explicit NetworkManager(QObject *parent = nullptr);
    ~NetworkManager();

    bool get(NetworkRequest* request);
    bool post(NetworkRequest* request,const QByteArray &data);
    bool post(NetworkRequest* request,const QIODevice *data);
    bool put(NetworkRequest* request,const QByteArray &data);
    bool put(NetworkRequest* request,const QIODevice *data);

    //设置应答数据处理器
    void setReplyHandler(NetworkReplyHandler* handler);

signals:

public slots:

private:
    NetworkReplyHandler* m_helper;
};

#endif // NETWORKMANAGER_H
