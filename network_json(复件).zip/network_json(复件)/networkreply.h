#ifndef NETWORKREPLY_H
#define NETWORKREPLY_H

#include <QObject>
#include<QNetworkReply>
#include"networkrequsettype.h"
class NetworkReply : public QObject
{
    Q_OBJECT
public:
    explicit NetworkReply(QObject *parent = nullptr);
    ~NetworkReply();

    void setReply(QNetworkReply* reply);
    QNetworkReply *getReply();

    //对应的网络请求类型
    NetworkRequestType::RequestType reply_getRequestType();

    void reply_setRequestType(NetworkRequestType::RequestType);

signals:
    void sig_myReplyFinished();
    void sig_myReplyReadyRead();

public slots:
    void slot_myReplayFinished();
private:

    NetworkRequestType::RequestType m_reply_requestType;
    QNetworkReply* m_reply;
};

#endif // NETWORKREPLY_H
